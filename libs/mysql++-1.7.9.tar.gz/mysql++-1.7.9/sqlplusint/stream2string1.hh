#ifndef __stream2string1_hh__
#define __stream2string1_hh__

template<class Strng, class T>
Strng stream2string(const T &object);

#endif
