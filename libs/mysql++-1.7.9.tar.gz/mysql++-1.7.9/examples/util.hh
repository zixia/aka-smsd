#ifndef _util_hh_
#define _util_hh_

#include <sqlplus.hh>

void print_stock_table(Query& query);

#endif
