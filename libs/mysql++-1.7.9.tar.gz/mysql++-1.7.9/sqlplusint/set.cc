
#include "set3.hh"

template class Set<set<string> >;
