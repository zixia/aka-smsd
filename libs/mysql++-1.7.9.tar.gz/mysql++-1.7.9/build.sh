#!/bin/sh
automake
autoconf
# MUST : add your configure options  here
./configure 
make 
