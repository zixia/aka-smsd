/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Define to empty if the keyword does not work.  */
/* #undef const */

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

/* Define if you have the strtol function.  */
#define HAVE_STRTOL 1

/* Define if you have the intl library (-lintl).  */
#define HAVE_LIBINTL 1

/* Define if you have the mysqlclient library (-lmysqlclient).  */
/* #undef HAVE_LIBMYSQLCLIENT */

/* Define if you have the nsl library (-lnsl).  */
#define HAVE_LIBNSL 1

/* Define if you have the socket library (-lsocket).  */
/* #undef HAVE_LIBSOCKET */

/* Name of package */
#define PACKAGE "sqlplus"

/* Version number of package */
#define VERSION "1.7.0"

/* Define if using the dmalloc debugging malloc package */
/* #undef WITH_DMALLOC */

